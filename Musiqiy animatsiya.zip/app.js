const btn = document.querySelector('.btn')
const audio = document.querySelector('.music')


btn.addEventListener('click', () => {
    audio.play()
    
})